﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string line = "";
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void monoFlat_Button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Введите число, которое спавнится последним по конфигу карты. Например: ''56'' \n(необязательно если вы хотите перезаписать конфиг пропов)");
        }

        private void monoFlat_Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void monoFlat_Button1_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(openFileDialog1.FileName);
                int linenum = 0;
                bool isEnt = false;
                bool isDynamic = false;
                string angles = "";
                string model = "";
                string lolz = textBox2.Text;
                int propquery = System.Convert.ToInt32(lolz);
                string result = "";
                bool ThatOne = false;
                while(line != null)
                {
                    line = sr.ReadLine();
                    if(line != null)
                    {
                        linenum += 1;
                        if(line == "entity")
                        {
                            isEnt = true;
                        }
                        if(isEnt == true)
                        {
                            if (line.Contains("prop_dynamic"))
                            {
                                    isDynamic = true;
                            }
                        }
                        if(line.Contains("angles"))
                        {
                            angles = line;
                        }
                        if(line.Contains("models/"))
                        {
                            model = line;
                        }
                        if(isDynamic == true)
                        {
                            string dbg = "";
                            if (line.Contains("LinkTo"))
                            {
                                ThatOne = true;
                                propquery += 1;
                            }
                        }
                        if(ThatOne == true)
                        {
                            if(line.Contains("origin"))
                            {
                                line = line.Replace("origin", "position");
                                result = result + "\t\"" + propquery + "\"" + "\n" + "\t{\n\t" + line + "\n\t" + angles + "\n\t" + model + "\n\t\t\"colors \"255 255 255 255\"" + "\n\t\t\"UnLockNum \"20\"" + "\n\t}\n";
                            }
                        }
                    }
                }

                line = sr.ReadLine();
                textBox1.Text = result;
                sr.Close();
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
